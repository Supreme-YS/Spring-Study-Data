package com.kmong.backend.modules.exception;

public class NotFoundException extends RuntimeException{
    public NotFoundException() {
        super();
    }
}
