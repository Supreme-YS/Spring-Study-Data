package com.kmong.backend.modules.exception;

public class UnAuthorizedException extends RuntimeException {
    public UnAuthorizedException() {
        super();
    }
}
